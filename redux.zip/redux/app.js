var inputTodo = document.getElementById('input');
var todoBtn = document.getElementById('btn');
var list = document.getElementById('list');

var ins = 'INSERT';
// var button = 'button';
var store = Redux.createStore(reducer, { valueT: [] });

function reducer(state, action) {
    switch (action.type) {
        case ins:
            var arr = state.valueT;
            arr.push(inputTodo.value);
            inputTodo.value = '';
            console.log(arr)
            state = {
             valueT: arr
            }
         
            break;
        default:
            return state;
    }
    console.log(state)
    
    return state;
}


function render() {
    // console.log(store.getState().valueT)
    var arrayValue = store.getState().valueT;
    arrayValue.map(function(todos){
     link = document.createElement('LI');
        var listValue = document.createTextNode(todos);
        link.appendChild(listValue);
    });
    list.appendChild(link);
    console.log(arrayValue)
    

}



store.subscribe(render);
todoBtn.onclick = function () {
    console.log("mmmm")
    store.dispatch({
        type: ins
    });
}